"use server"

import { revalidatePath } from "next/cache"
import { db } from "@/lib/db"
import { auth } from "@/auth"

interface CustomerData {
    name: string
    phone?: string
    email?: string
    address?: string
    city?: string
    taxId?: string
    barcode?: string
    notes?: string
    clientType?: string
}

export const getCustomers = async () => {
    const session = await auth()
    if (!session?.user?.id) return { error: "Unauthorized" }

    // @ts-expect-error tenantId not typed in session yet
    const tenantId = session.user.tenantId

    if (!tenantId) return { error: "Tenant ID missing from session" }

    try {
        const customers = await db.customer.findMany({
            where: { tenantId },
            orderBy: { createdAt: "desc" }
        })
        return { customers }
    } catch (_error) {
        return { error: "Failed to fetch customers" }
    }
}

export const createCustomer = async (data: CustomerData) => {
    const session = await auth()
    if (!session?.user?.id) return { error: "Unauthorized" }

    // @ts-expect-error tenantId not typed in session yet
    const tenantId = session.user.tenantId

    try {
        const customer = await db.customer.create({
            data: {
                ...data,
                tenantId
            }
        })
        revalidatePath("/(dashboard)/customers")
        return { success: "Customer created", id: customer.id }
    } catch (error) {
        console.error("createCustomer error:", error)
        return { error: `Failed to create customer: ${error instanceof Error ? error.message : String(error)}` }
    }
}

export const updateCustomer = async (id: string, data: CustomerData) => {
    const session = await auth()
    if (!session?.user?.id) return { error: "Unauthorized" }

    try {
        const customer = await db.customer.update({
            where: { id },
            data
        })
        revalidatePath("/(dashboard)/customers")
        return { success: "Customer updated", id: customer.id }
    } catch (_error) {
        return { error: "Failed to update customer" }
    }
}

export const deleteCustomer = async (id: string) => {
    const session = await auth()
    if (!session?.user?.id) return { error: "Unauthorized" }

    try {
        await db.customer.delete({
            where: { id }
        })
        revalidatePath("/(dashboard)/customers")
        return { success: "Customer deleted" }
    } catch (_error) {
        return { error: "Failed to delete customer" }
    }
}

export const getUnpaidCustomers = async () => {
    const session = await auth()
    if (!session?.user?.id) return { error: "Unauthorized" }
    // @ts-expect-error tenantId
    const tenantId = session.user.tenantId
    if (!tenantId) return { error: "Tenant ID missing" }

    try {
        const customers = await db.customer.findMany({
            where: { tenantId, balance: { gt: 0 } },
            orderBy: { balance: "desc" }
        })
        return { customers: JSON.parse(JSON.stringify(customers)) }
    } catch (_error) {
        return { error: "Failed to fetch unpaid customers" }
    }
}

export const registerCustomerPayment = async (data: { customerId: string; amount: number; accountId: string; notes?: string; date?: Date | string }) => {
    const session = await auth()
    if (!session?.user?.id) return { error: "Unauthorized" }
    // @ts-expect-error tenantId
    const tenantId = session.user.tenantId
    if (!tenantId) return { error: "Tenant ID missing" }

    try {
        await db.$transaction(async (tx) => {
            // 1. Decrease customer balance
            await tx.customer.update({
                where: { id: data.customerId },
                data: { balance: { decrement: data.amount } }
            });

            // 2. Increase Treasury Account balance
            const account = await tx.treasuryAccount.update({
                where: { id: data.accountId },
                data: { balance: { increment: data.amount } }
            });

            // 3. Log transaction
            await tx.treasuryTransaction.create({
                data: {
                    tenantId,
                    accountId: data.accountId,
                    type: "CREDIT",
                    amount: data.amount,
                    balanceBefore: Number(account.balance) - data.amount,
                    balanceAfter: account.balance,
                    source: "MANUAL_IN",
                    referenceId: data.customerId, // Link to customer
                    description: `Paiement Client: ${data.notes || "Règlement de dette"}`,
                    date: data.date ? new Date(data.date) : new Date(),
                }
            });
        });

        revalidatePath("/(dashboard)/customers")
        revalidatePath("/(dashboard)/treasury")
        return { success: "Payment registered successfully" }
    } catch (error) {
        console.error("registerCustomerPayment error:", error)
        return { error: "Failed to register payment" }
    }
}
