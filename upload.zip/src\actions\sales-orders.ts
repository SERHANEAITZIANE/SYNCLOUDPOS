"use server"

import { db } from "@/lib/db"
import { auth } from "@/auth"
import { revalidatePath } from "next/cache"

// Helper: generate receipt number
export async function generateReceiptNumber(type: string, tenantId: string) {
    const prefixMap: Record<string, string> = {
        "QUOTE": "DE",
        "ORDER": "BL",
        "INVOICE": "FA"
    }
    const prefix = prefixMap[type] || "XX"
    const year = new Date().getFullYear()
    const pattern = `${prefix}-${year}/`

    const lastOrder = await db.salesOrder.findFirst({
        where: { tenantId, type, receiptNumber: { startsWith: pattern } },
        orderBy: { createdAt: "desc" }
    })

    let sequence = 1
    if (lastOrder?.receiptNumber) {
        const parts = lastOrder.receiptNumber.split("/")
        if (parts.length === 2) {
            const lastSeq = parseInt(parts[1])
            if (!isNaN(lastSeq)) sequence = lastSeq + 1
        }
    }

    return `${pattern}${sequence.toString().padStart(4, "0")}`
}

// Status transitions that affect stock
const STOCK_STATUSES = ["VALIDATED", "PAID"]
// Status transitions that mean customer owes money
const DEBT_STATUSES = ["VALIDATED"]
const PAID_STATUSES = ["PAID"]

export async function createSalesOrder(data: {
    customerId: string
    type: string
    status: string
    items: { productId: string; quantity: number; unitPrice: number }[]
    total: number
    receiptNumber?: string
}) {
    try {
        const session = await auth()
        if (!session?.user?.id) throw new Error("Unauthorized")
        // @ts-expect-error tenantId
        const tenantId = session.user.tenantId
        if (!tenantId) throw new Error("Tenant ID missing")

        const receiptNumber = await generateReceiptNumber(data.type, tenantId)

        const salesOrder = await db.$transaction(async (tx) => {
            const order = await tx.salesOrder.create({
                data: {
                    tenantId,
                    customerId: data.customerId,
                    type: data.type,
                    status: data.status,
                    total: data.total,
                    receiptNumber,
                    items: {
                        create: data.items.map(item => ({
                            productId: item.productId,
                            quantity: item.quantity,
                            unitPrice: item.unitPrice
                        }))
                    }
                }
            })

            // Deduct stock for BON DE LIVRAISON (ORDER) or INVOICE validated/paid
            const shouldDeductStock =
                (data.type === "ORDER" || data.type === "INVOICE") &&
                STOCK_STATUSES.includes(data.status)

            if (shouldDeductStock) {
                for (const item of data.items) {
                    await tx.product.update({
                        where: { id: item.productId },
                        data: { stock: { decrement: item.quantity } }
                    })
                }
            }

            // Add to customer balance if validated (not yet paid)
            if (DEBT_STATUSES.includes(data.status)) {
                await tx.customer.update({
                    where: { id: data.customerId },
                    data: { balance: { increment: data.total } }
                })
            }

            return order
        })

        revalidatePath("/(dashboard)/sales")
        return { success: true, id: salesOrder.id }
    } catch (error) {
        console.error("[CREATE_SALES_ORDER]", error)
        throw new Error(`Erreur: ${error instanceof Error ? error.message : "Unknown"}`)
    }
}

export async function getSalesOrders(type?: string) {
    try {
        const session = await auth()
        if (!session?.user?.id) throw new Error("Unauthorized")
        // @ts-expect-error tenantId
        const tenantId = session.user.tenantId

        const salesOrders = await db.salesOrder.findMany({
            where: { tenantId, ...(type ? { type } : {}) },
            include: { customer: true, items: { include: { product: true } } },
            orderBy: { createdAt: "desc" }
        })

        return JSON.parse(JSON.stringify(salesOrders))
    } catch (error) {
        console.error("[GET_SALES_ORDERS]", error)
        return []
    }
}

export async function getSalesOrder(id: string) {
    try {
        const session = await auth()
        if (!session?.user?.id) throw new Error("Unauthorized")

        const salesOrder = await db.salesOrder.findUnique({
            where: { id },
            include: {
                customer: true,
                items: { include: { product: { include: { barcodes: true } } } }
            }
        })

        return JSON.parse(JSON.stringify(salesOrder))
    } catch (error) {
        console.error("[GET_SALES_ORDER]", error)
        return null
    }
}

export async function getSalesOrderByReceipt(receiptNumber: string) {
    try {
        const session = await auth()
        if (!session?.user?.id) throw new Error("Unauthorized")
        // @ts-expect-error tenantId
        const tenantId = session.user.tenantId

        const salesOrder = await db.salesOrder.findFirst({
            where: { receiptNumber, tenantId },
            include: {
                customer: true,
                items: { include: { product: { include: { barcodes: true } } } }
            }
        })

        return salesOrder ? JSON.parse(JSON.stringify(salesOrder)) : null
    } catch (error) {
        console.error("[GET_SALES_ORDER_BY_RECEIPT]", error)
        return null
    }
}

export async function searchRecentSalesOrders(query: string, type: string = "ORDER") {
    try {
        const session = await auth()
        if (!session?.user?.id) throw new Error("Unauthorized")
        // @ts-expect-error tenantId
        const tenantId = session.user.tenantId

        const salesOrders = await db.salesOrder.findMany({
            where: {
                tenantId,
                type,
                OR: [
                    { receiptNumber: { contains: query } },
                    { customer: { name: { contains: query } } }
                ]
            },
            include: {
                customer: true,
                items: { include: { product: { include: { barcodes: true } } } }
            },
            orderBy: { createdAt: "desc" },
            take: 20
        })

        return JSON.parse(JSON.stringify(salesOrders))
    } catch (error) {
        console.error("[SEARCH_RECENT_SALES_ORDERS]", error)
        return []
    }
}

export async function updateSalesOrder(id: string, data: {
    customerId: string
    type: string
    status: string
    items: { productId: string; quantity: number; unitPrice: number }[]
    total: number
}) {
    try {
        const session = await auth()
        if (!session?.user?.id) throw new Error("Unauthorized")
        // @ts-expect-error tenantId
        const tenantId = session.user.tenantId

        const existing = await db.salesOrder.findUnique({ where: { id, tenantId }, include: { items: true } })
        if (!existing) return { error: "Bon introuvable" }
        if (!["DRAFT"].includes(existing.status)) return { error: "Seuls les brouillons peuvent être modifiés" }

        await db.$transaction(async (tx) => {
            await tx.salesOrderItem.deleteMany({ where: { salesOrderId: id } })
            await tx.salesOrder.update({
                where: { id },
                data: {
                    customerId: data.customerId,
                    type: data.type,
                    total: data.total,
                    items: {
                        create: data.items.map(item => ({
                            productId: item.productId,
                            quantity: item.quantity,
                            unitPrice: item.unitPrice
                        }))
                    }
                }
            })
        })

        revalidatePath("/(dashboard)/sales")
        return { success: "Bon modifié" }
    } catch (error) {
        console.error("[UPDATE_SALES_ORDER]", error)
        return { error: "Erreur lors de la modification" }
    }
}

export async function updateSalesOrderStatus(id: string, newStatus: string) {
    try {
        const session = await auth()
        if (!session?.user?.id) throw new Error("Unauthorized")
        // @ts-expect-error tenantId
        const tenantId = session.user.tenantId

        const salesOrder = await db.salesOrder.findUnique({
            where: { id, tenantId },
            include: { items: true }
        })
        if (!salesOrder) throw new Error("Bon introuvable")

        const prevStatus = salesOrder.status
        const total = Number(salesOrder.total)

        await db.$transaction(async (tx) => {
            await tx.salesOrder.update({ where: { id }, data: { status: newStatus } })

            // Stock: deduct when going to VALIDATED/PAID (and not already deducted)
            const hadStock = STOCK_STATUSES.includes(prevStatus)
            const getsStock = STOCK_STATUSES.includes(newStatus)
            const isStockType = salesOrder.type === "ORDER" || salesOrder.type === "INVOICE"

            if (!hadStock && getsStock && isStockType) {
                for (const item of salesOrder.items) {
                    await tx.product.update({
                        where: { id: item.productId },
                        data: { stock: { decrement: item.quantity } }
                    })
                }
            }

            // Restore stock if cancelling
            if (hadStock && newStatus === "CANCELLED" && isStockType) {
                for (const item of salesOrder.items) {
                    await tx.product.update({
                        where: { id: item.productId },
                        data: { stock: { increment: item.quantity } }
                    })
                }
            }

            // Customer balance:
            // VALIDATED → add to balance (they owe us)
            if (DEBT_STATUSES.includes(newStatus) && !DEBT_STATUSES.includes(prevStatus)) {
                await tx.customer.update({
                    where: { id: salesOrder.customerId },
                    data: { balance: { increment: total } }
                })
            }

            // PAID → clear balance they owed for this order
            if (newStatus === "PAID" && !PAID_STATUSES.includes(prevStatus) && !DEBT_STATUSES.includes(prevStatus)) {
                // Coming straight from DRAFT to PAID without previous debt record — no balance change needed
            }
            // PAID from VALIDATED → reduce balance (they paid)
            if (newStatus === "PAID" && DEBT_STATUSES.includes(prevStatus)) {
                await tx.customer.update({
                    where: { id: salesOrder.customerId },
                    data: { balance: { decrement: total } }
                })
            }

            // CANCELLED from VALIDATED → clear balance
            if (newStatus === "CANCELLED" && DEBT_STATUSES.includes(prevStatus)) {
                await tx.customer.update({
                    where: { id: salesOrder.customerId },
                    data: { balance: { decrement: total } }
                })
            }
        })

        revalidatePath("/(dashboard)/sales")
        return { success: true, id }
    } catch (error) {
        console.error("[UPDATE_SALES_ORDER_STATUS]", error)
        throw new Error("Internal Error")
    }
}

export async function deleteSalesOrder(id: string) {
    try {
        const session = await auth()
        if (!session?.user?.id) throw new Error("Unauthorized")
        // @ts-expect-error tenantId
        const tenantId = session.user.tenantId

        await db.salesOrder.delete({ where: { id, tenantId } })
        revalidatePath("/(dashboard)/sales")
        return { success: "Supprimé" }
    } catch { return { error: "Erreur" } }
}
