"use server"

import { revalidatePath } from "next/cache"
import { db } from "@/lib/db"
import { auth } from "@/auth"

interface PurchaseOrderItemData {
    productId: string
    quantity: number
    costPrice: number
}

interface PurchaseOrderData {
    supplierId: string
    total: number
    status: string
    items: PurchaseOrderItemData[]
    accountId?: string
    notes?: string
}

export const getPurchaseOrders = async () => {
    const session = await auth()
    if (!session?.user?.id) return { error: "Unauthorized" }
    // @ts-expect-error tenantId not typed in session yet
    const tenantId = session.user.tenantId

    try {
        const purchaseOrders = await db.purchaseOrder.findMany({
            where: { tenantId },
            include: {
                supplier: true,
                items: { include: { product: true } }
            },
            orderBy: { createdAt: "desc" }
        })
        return { purchaseOrders: JSON.parse(JSON.stringify(purchaseOrders)) }
    } catch { return { error: "Failed to fetch purchase orders" } }
}

export const getPurchaseOrder = async (id: string) => {
    const session = await auth()
    if (!session?.user?.id) return { error: "Unauthorized" }

    try {
        const purchaseOrder = await db.purchaseOrder.findUnique({
            where: { id },
            include: {
                supplier: true,
                items: { include: { product: { include: { barcodes: true } } } }
            }
        })
        return { purchaseOrder: JSON.parse(JSON.stringify(purchaseOrder)) }
    } catch { return { error: "Failed to fetch purchase order" } }
}

export const createPurchaseOrder = async (data: PurchaseOrderData) => {
    const session = await auth()
    if (!session?.user?.id) return { error: "Unauthorized" }
    // @ts-expect-error tenantId not typed in session yet
    const tenantId = session.user.tenantId

    try {
        const result = await db.$transaction(async (tx) => {
            const purchaseOrder = await tx.purchaseOrder.create({
                data: {
                    tenantId,
                    supplierId: data.supplierId,
                    accountId: (data.accountId && data.accountId !== "none") ? data.accountId : undefined,
                    total: data.total,
                    status: data.status,
                    items: {
                        create: data.items.map(item => ({
                            productId: item.productId,
                            quantity: item.quantity,
                            costPrice: item.costPrice
                        }))
                    }
                },
                include: { items: true }
            })

            // If BON_LIVRAISON or FACTURE or COMPLETED: add stock
            if (["BON_LIVRAISON", "FACTURE", "COMPLETED"].includes(data.status)) {
                for (const item of data.items) {
                    await tx.product.update({
                        where: { id: item.productId },
                        data: { stock: { increment: item.quantity }, cost: item.costPrice }
                    })
                }
            }

            // If FACTURE: add to supplier balance (we owe them)
            if (data.status === "FACTURE") {
                await (tx as any).supplier.update({
                    where: { id: data.supplierId },
                    data: { balance: { increment: data.total } }
                })
            }

            // If COMPLETED: deduct from treasury if account provided
            if (data.status === "COMPLETED" && data.accountId && data.accountId !== "none" && data.total > 0) {
                const account = await tx.treasuryAccount.findUnique({ where: { id: data.accountId, tenantId } })
                if (account) {
                    if (Number(account.balance) < data.total) throw new Error("Solde insuffisant dans le compte sélectionné")
                    const updated = await tx.treasuryAccount.update({
                        where: { id: data.accountId },
                        data: { balance: { decrement: data.total } }
                    })
                    await tx.treasuryTransaction.create({
                        data: {
                            accountId: data.accountId,
                            type: "DEBIT",
                            amount: data.total,
                            balanceBefore: account.balance,
                            balanceAfter: updated.balance,
                            source: "PURCHASE",
                            referenceId: purchaseOrder.id,
                            description: `Bon de commande - Paiement`,
                            tenantId
                        }
                    })
                }
            }

            return purchaseOrder
        })

        revalidatePath("/(dashboard)/purchases")
        return { success: "Bon de commande créé", id: result.id }
    } catch (error) {
        console.error("Create Purchase Order Error:", error)
        const msg = error instanceof Error ? error.message : "Failed to create purchase order"
        return { error: msg }
    }
}

// Update items of a PENDING purchase order
export const updatePurchaseOrder = async (id: string, data: PurchaseOrderData) => {
    const session = await auth()
    if (!session?.user?.id) return { error: "Unauthorized" }
    // @ts-expect-error tenantId not typed in session yet
    const tenantId = session.user.tenantId

    try {
        const existing = await db.purchaseOrder.findUnique({ where: { id, tenantId } })
        if (!existing) return { error: "Bon de commande introuvable" }
        if (existing.status !== "PENDING" && existing.status !== "BON_COMMANDE") {
            return { error: "Seuls les bons PENDING ou BON_COMMANDE peuvent être modifiés" }
        }

        await db.$transaction(async (tx) => {
            // Delete existing items
            await tx.purchaseOrderItem.deleteMany({ where: { purchaseOrderId: id } })
            // Update order
            await tx.purchaseOrder.update({
                where: { id },
                data: {
                    supplierId: data.supplierId,
                    total: data.total,
                    status: data.status,
                    accountId: (data.accountId && data.accountId !== "none") ? data.accountId : undefined,
                    items: {
                        create: data.items.map(item => ({
                            productId: item.productId,
                            quantity: item.quantity,
                            costPrice: item.costPrice
                        }))
                    }
                }
            })
        })

        revalidatePath("/(dashboard)/purchases")
        return { success: "Bon de commande modifié" }
    } catch (error) {
        console.error("Update Purchase Order Error:", error)
        return { error: "Erreur lors de la modification" }
    }
}

// Transition a purchase order status with side effects
export const updatePurchaseOrderStatus = async (id: string, newStatus: string, accountId?: string) => {
    const session = await auth()
    if (!session?.user?.id) return { error: "Unauthorized" }
    // @ts-expect-error tenantId not typed in session yet
    const tenantId = session.user.tenantId

    try {
        const order = await db.purchaseOrder.findUnique({
            where: { id, tenantId },
            include: { items: true }
        })
        if (!order) return { error: "Bon de commande introuvable" }

        const prevStatus = order.status
        const total = Number(order.total)

        await db.$transaction(async (tx) => {
            await tx.purchaseOrder.update({ where: { id }, data: { status: newStatus } })

            // Stock update: only if going TO a status that receives stock (and not already having done so)
            const stockStatuses = ["BON_LIVRAISON", "FACTURE", "COMPLETED"]
            const hadStock = stockStatuses.includes(prevStatus)
            const getsStock = stockStatuses.includes(newStatus)

            if (!hadStock && getsStock) {
                for (const item of order.items) {
                    await tx.product.update({
                        where: { id: item.productId },
                        data: { stock: { increment: item.quantity }, cost: item.costPrice }
                    })
                }
            }

            // If cancelling after stock was received: reverse stock
            if (hadStock && newStatus === "CANCELLED") {
                for (const item of order.items) {
                    await tx.product.update({
                        where: { id: item.productId },
                        data: { stock: { decrement: item.quantity } }
                    })
                }
            }

            // Supplier balance: increment when moving to FACTURE (first time)
            if (newStatus === "FACTURE" && prevStatus !== "FACTURE") {
                await (tx as any).supplier.update({
                    where: { id: order.supplierId },
                    data: { balance: { increment: total } }
                })
            }

            // Pay supplier: if setting COMPLETED with accountId, deduct treasury and reset supplier balance
            if (newStatus === "COMPLETED" && accountId && accountId !== "none" && total > 0) {
                const account = await tx.treasuryAccount.findUnique({ where: { id: accountId, tenantId } })
                if (account) {
                    if (Number(account.balance) < total) throw new Error("Solde insuffisant")
                    const updated = await tx.treasuryAccount.update({
                        where: { id: accountId },
                        data: { balance: { decrement: total } }
                    })
                    await tx.treasuryTransaction.create({
                        data: {
                            accountId,
                            type: "DEBIT",
                            amount: total,
                            balanceBefore: account.balance,
                            balanceAfter: updated.balance,
                            source: "PURCHASE",
                            referenceId: id,
                            description: `Paiement fournisseur - Bon #${id.slice(-6)}`,
                            tenantId
                        }
                    })
                    // If supplier had balance (was invoiced), reduce it
                    if (prevStatus === "FACTURE") {
                        await (tx as any).supplier.update({
                            where: { id: order.supplierId },
                            data: { balance: { decrement: total } }
                        })
                    }
                }
            }
        })

        revalidatePath("/(dashboard)/purchases")
        return { success: `Statut mis à jour: ${newStatus}` }
    } catch (error) {
        console.error("Update Purchase Order Status Error:", error)
        const msg = error instanceof Error ? error.message : "Erreur"
        return { error: msg }
    }
}

export const deletePurchaseOrder = async (id: string) => {
    const session = await auth()
    if (!session?.user?.id) return { error: "Unauthorized" }
    // @ts-expect-error tenantId not typed in session yet
    const tenantId = session.user.tenantId

    try {
        await db.purchaseOrder.delete({ where: { id, tenantId } })
        revalidatePath("/(dashboard)/purchases")
        return { success: "Supprimé" }
    } catch { return { error: "Erreur lors de la suppression" } }
}
