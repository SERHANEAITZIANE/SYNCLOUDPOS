"use server"

import * as z from "zod"
import bcrypt from "bcryptjs"
import { db } from "@/lib/db"
import { RegisterSchema } from "@/schemas"
import { getUserByEmail } from "@/data/user"

export const register = async (values: z.infer<typeof RegisterSchema>) => {
    const validatedFields = RegisterSchema.safeParse(values)

    if (!validatedFields.success) {
        return { error: "Invalid fields!" }
    }

    const { email, password, name } = validatedFields.data
    const hashedPassword = await bcrypt.hash(password, 10)

    const existingUser = await getUserByEmail(email)

    if (existingUser) {
        return { error: "Email already in use!" }
    }

    try {
        // Create default tenant for new user (or assign to existing one logic later)
        // For now, create a new tenant for each user
        const tenant = await db.tenant.create({
            data: {
                name: `${name}'s Shop`,
            }
        })

        await db.user.create({
            data: {
                name,
                email,
                password: hashedPassword,
                tenantId: tenant.id,
                role: "ADMIN" // First user is Admin
            },
        })

        return { success: "User created!" }
    } catch (error) {
        console.error("[REGISTER_ACTION_ERROR]", error)
        return { error: "Something went wrong during registration." }
    }
}
