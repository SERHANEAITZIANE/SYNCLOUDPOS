"use client"

import { ColumnDef } from "@tanstack/react-table"
import { CellAction } from "./cell-action"
import { format } from "date-fns"
import { Badge } from "@/components/ui/badge"

export type TenantColumn = {
    id: string;
    name: string;
    phone: string | null;
    subscriptionEndsAt: Date | null;
    createdAt: Date;
    ownerDetails: {
        name: string | null;
        email: string;
        phone: string | null;
    } | null;
}

export const columns: ColumnDef<TenantColumn>[] = [
    {
        accessorKey: "name",
        header: "Nom de l'Espace (Tenant)",
    },
    {
        id: "owner",
        header: "Propriétaire",
        cell: ({ row }) => {
            const owner = row.original.ownerDetails;
            return owner ? (
                <div className="flex flex-col">
                    <span className="font-medium text-sm">{owner.name}</span>
                    <span className="text-xs text-muted-foreground">{owner.email}</span>
                </div>
            ) : "N/A"
        }
    },
    {
        id: "phones",
        header: "Téléphones",
        cell: ({ row }) => {
            const orgPhone = row.original.phone;
            const ownerPhone = row.original.ownerDetails?.phone;

            return (
                <div className="flex flex-col gap-1">
                    {orgPhone && <span className="text-xs break-keep whitespace-nowrap">Org: {orgPhone}</span>}
                    {ownerPhone && <span className="text-xs break-keep whitespace-nowrap">User: {ownerPhone}</span>}
                    {!orgPhone && !ownerPhone && <span className="text-xs text-muted-foreground">Aucun</span>}
                </div>
            )
        }
    },
    {
        accessorKey: "createdAt",
        header: "Date de création",
        cell: ({ row }) => format(row.original.createdAt, "dd/MM/yyyy")
    },
    {
        accessorKey: "subscriptionEndsAt",
        header: "Expiration",
        cell: ({ row }) => {
            const date = row.original.subscriptionEndsAt;
            if (!date) return <Badge variant="secondary">Inconnue</Badge>;

            const isExpired = new Date(date) < new Date();
            return (
                <Badge variant={isExpired ? "destructive" : "default"} className={!isExpired ? "bg-emerald-500 hover:bg-emerald-600" : ""}>
                    {format(new Date(date), "dd/MM/yyyy")}
                </Badge>
            )
        }
    },
    {
        id: "actions",
        cell: ({ row }) => <CellAction data={row.original} />
    }
]
